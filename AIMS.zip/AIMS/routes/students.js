const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { isAuthenticated, isAdmin, isAdminOrTeacher } = require('../middleware/auth');

// GET /api/students - Admin & Teacher can view all
router.get('/', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT s.*, d.Dept_Name FROM student s
       LEFT JOIN department d ON s.Dept_ID = d.Dept_ID
       ORDER BY s.Student_ID DESC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

// GET /api/students/my - Student can view own profile
router.get('/my', isAuthenticated, async (req, res) => {
  if (req.session.user.role !== 'student')
    return res.status(403).json({ error: 'Access denied.' });
  try {
    const [rows] = await pool.execute(
      `SELECT s.*, d.Dept_Name FROM student s
       LEFT JOIN department d ON s.Dept_ID = d.Dept_ID
       WHERE s.Student_ID = ?`,
      [req.session.user.reference_id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Profile not found.' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// GET /api/students/:id
router.get('/:id', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT s.*, d.Dept_Name FROM student s
       LEFT JOIN department d ON s.Dept_ID = d.Dept_ID
       WHERE s.Student_ID = ?`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Student not found.' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// POST /api/students - Admin only
router.post('/', isAuthenticated, isAdmin, async (req, res) => {
  const { Name, Email, Phone, Address, Gender, Date_of_Birth, Admission_Year, Dept_ID } = req.body;
  if (!Name || !Email) return res.status(400).json({ error: 'Name and Email are required.' });
  try {
    const [result] = await pool.execute(
      `INSERT INTO student (Name, Email, Phone, Address, Gender, Date_of_Birth, Admission_Year, Dept_ID)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [Name, Email, Phone || null, Address || null, Gender || null, Date_of_Birth || null, Admission_Year || null, Dept_ID || null]
    );
    const [newRow] = await pool.execute('SELECT * FROM student WHERE Student_ID = ?', [result.insertId]);
    res.status(201).json(newRow[0]);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Email already exists.' });
    res.status(500).json({ error: 'Server error.' });
  }
});

// PUT /api/students/:id - Admin only
router.put('/:id', isAuthenticated, isAdmin, async (req, res) => {
  const { Name, Email, Phone, Address, Gender, Date_of_Birth, Admission_Year, Dept_ID } = req.body;
  if (!Name || !Email) return res.status(400).json({ error: 'Name and Email are required.' });
  try {
    const [result] = await pool.execute(
      `UPDATE student SET Name=?, Email=?, Phone=?, Address=?, Gender=?, Date_of_Birth=?, Admission_Year=?, Dept_ID=?
       WHERE Student_ID=?`,
      [Name, Email, Phone || null, Address || null, Gender || null, Date_of_Birth || null, Admission_Year || null, Dept_ID || null, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Student not found.' });
    const [updated] = await pool.execute('SELECT * FROM student WHERE Student_ID = ?', [req.params.id]);
    res.json(updated[0]);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Email already exists.' });
    res.status(500).json({ error: 'Server error.' });
  }
});

// DELETE /api/students/:id - Admin only
router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM student WHERE Student_ID = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Student not found.' });
    res.json({ message: 'Student deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
