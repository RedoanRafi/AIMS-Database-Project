// routes/attendance.js
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { isAuthenticated, isAdmin, isAdminOrTeacher } = require('../middleware/auth');

// GET per-course attendance stats
router.get('/stats', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT c.Course_ID, c.Course_Name,
        COUNT(DISTINCT a.Date) AS total_classes,
        COUNT(a.Attendance_ID) AS total_records,
        SUM(CASE WHEN a.Status='Present' THEN 1 ELSE 0 END) AS present_count,
        SUM(CASE WHEN a.Status='Absent' THEN 1 ELSE 0 END) AS absent_count,
        SUM(CASE WHEN a.Status='Late' THEN 1 ELSE 0 END) AS late_count
       FROM course c
       LEFT JOIN attendance a ON c.Course_ID = a.Course_ID
       GROUP BY c.Course_ID, c.Course_Name
       ORDER BY c.Course_Name`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

// GET all attendance (optionally filtered by course)
router.get('/', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const { course_id } = req.query;
    let sql = `SELECT a.*, s.Name AS Student_Name, c.Course_Name FROM attendance a
               LEFT JOIN student s ON a.Student_ID = s.Student_ID
               LEFT JOIN course c ON a.Course_ID = c.Course_ID`;
    const params = [];
    if (course_id) { sql += ' WHERE a.Course_ID = ?'; params.push(course_id); }
    sql += ' ORDER BY a.Date DESC, s.Name';
    const [rows] = await pool.execute(sql, params);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

// GET student's own attendance
router.get('/my', isAuthenticated, async (req, res) => {
  if (req.session.user.role !== 'student')
    return res.status(403).json({ error: 'Access denied.' });
  try {
    const [rows] = await pool.execute(
      `SELECT a.*, c.Course_Name,
        (SELECT COUNT(*) FROM attendance a2 WHERE a2.Course_ID=a.Course_ID AND a2.Student_ID=a.Student_ID AND a2.Status='Present') AS my_present,
        (SELECT COUNT(DISTINCT Date) FROM attendance a3 WHERE a3.Course_ID=a.Course_ID) AS total_classes
       FROM attendance a
       LEFT JOIN course c ON a.Course_ID = c.Course_ID
       WHERE a.Student_ID = ? ORDER BY a.Date DESC`,
      [req.session.user.reference_id]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.get('/:id', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM attendance WHERE Attendance_ID = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Not found.' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.post('/', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  const { Student_ID, Course_ID, Date: AttDate, Status } = req.body;
  if (!Student_ID || !Course_ID || !AttDate || !Status)
    return res.status(400).json({ error: 'All fields are required.' });
  try {
    // Check student is enrolled in course
    const [enrolled] = await pool.execute(
      'SELECT Enroll_ID FROM enrollment WHERE Student_ID=? AND Course_ID=?',
      [Student_ID, Course_ID]
    );
    if (enrolled.length === 0)
      return res.status(400).json({ error: 'Student is not enrolled in this course.' });

    const [result] = await pool.execute(
      'INSERT INTO attendance (Student_ID, Course_ID, Date, Status) VALUES (?, ?, ?, ?)',
      [Student_ID, Course_ID, AttDate, Status]
    );
    const [newRow] = await pool.execute(
      `SELECT a.*, s.Name AS Student_Name, c.Course_Name FROM attendance a
       LEFT JOIN student s ON a.Student_ID = s.Student_ID
       LEFT JOIN course c ON a.Course_ID = c.Course_ID
       WHERE a.Attendance_ID = ?`, [result.insertId]
    );
    res.status(201).json(newRow[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.put('/:id', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  const { Student_ID, Course_ID, Date: AttDate, Status } = req.body;
  if (!Student_ID || !Course_ID || !AttDate || !Status)
    return res.status(400).json({ error: 'All fields are required.' });
  try {
    const [result] = await pool.execute(
      'UPDATE attendance SET Student_ID=?, Course_ID=?, Date=?, Status=? WHERE Attendance_ID=?',
      [Student_ID, Course_ID, AttDate, Status, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Record not found.' });
    const [updated] = await pool.execute(
      `SELECT a.*, s.Name AS Student_Name, c.Course_Name FROM attendance a
       LEFT JOIN student s ON a.Student_ID = s.Student_ID
       LEFT JOIN course c ON a.Course_ID = c.Course_ID
       WHERE a.Attendance_ID = ?`, [req.params.id]
    );
    res.json(updated[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM attendance WHERE Attendance_ID = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Record not found.' });
    res.json({ message: 'Attendance record deleted.' });
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

module.exports = router;
