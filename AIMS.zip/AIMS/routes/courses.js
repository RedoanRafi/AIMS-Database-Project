// routes/courses.js
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { isAuthenticated, isAdmin, isAdminOrTeacher } = require('../middleware/auth');

// GET all courses with dept + teacher info
router.get('/', isAuthenticated, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT c.*, d.Dept_Name, t.Name AS Teacher_Name,
        (SELECT COUNT(*) FROM enrollment e WHERE e.Course_ID = c.Course_ID) AS enrolled_count
       FROM course c
       LEFT JOIN department d ON c.Dept_ID = d.Dept_ID
       LEFT JOIN teacher t ON c.Teacher_ID = t.Teacher_ID
       ORDER BY c.Course_ID`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

// GET single course
router.get('/:id', isAuthenticated, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT c.*, d.Dept_Name, t.Name AS Teacher_Name FROM course c
       LEFT JOIN department d ON c.Dept_ID = d.Dept_ID
       LEFT JOIN teacher t ON c.Teacher_ID = t.Teacher_ID
       WHERE c.Course_ID = ?`, [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Not found.' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

// POST create course (admin only)
router.post('/', isAuthenticated, isAdmin, async (req, res) => {
  const { Course_ID, Course_Name, Credits, Dept_ID, Teacher_ID } = req.body;
  if (!Course_ID || !Course_Name || !Credits)
    return res.status(400).json({ error: 'Course_ID, Course_Name and Credits are required.' });
  try {
    await pool.execute(
      'INSERT INTO course (Course_ID, Course_Name, Credits, Dept_ID, Teacher_ID) VALUES (?, ?, ?, ?, ?)',
      [Course_ID, Course_Name, Credits, Dept_ID || null, Teacher_ID || null]
    );
    const [newRow] = await pool.execute(
      `SELECT c.*, d.Dept_Name, t.Name AS Teacher_Name FROM course c
       LEFT JOIN department d ON c.Dept_ID = d.Dept_ID
       LEFT JOIN teacher t ON c.Teacher_ID = t.Teacher_ID
       WHERE c.Course_ID = ?`, [Course_ID]
    );
    res.status(201).json(newRow[0]);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Course ID already exists.' });
    res.status(500).json({ error: 'Server error.' });
  }
});

// PUT update course - admin assigns teacher here
router.put('/:id', isAuthenticated, isAdmin, async (req, res) => {
  const { Course_Name, Credits, Dept_ID, Teacher_ID } = req.body;
  if (!Course_Name || !Credits) return res.status(400).json({ error: 'Course_Name and Credits required.' });
  try {
    const [result] = await pool.execute(
      'UPDATE course SET Course_Name=?, Credits=?, Dept_ID=?, Teacher_ID=? WHERE Course_ID=?',
      [Course_Name, Credits, Dept_ID || null, Teacher_ID || null, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Course not found.' });
    const [updated] = await pool.execute(
      `SELECT c.*, d.Dept_Name, t.Name AS Teacher_Name FROM course c
       LEFT JOIN department d ON c.Dept_ID = d.Dept_ID
       LEFT JOIN teacher t ON c.Teacher_ID = t.Teacher_ID
       WHERE c.Course_ID = ?`, [req.params.id]
    );
    res.json(updated[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

// DELETE course (admin only)
router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM course WHERE Course_ID = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Course not found.' });
    res.json({ message: 'Course deleted.' });
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

module.exports = router;
