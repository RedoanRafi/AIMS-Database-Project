// routes/enrollment.js
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { isAuthenticated, isAdmin, isAdminOrTeacher } = require('../middleware/auth');

// GET all enrollments
router.get('/', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT e.*, s.Name AS Student_Name, c.Course_Name FROM enrollment e
       LEFT JOIN student s ON e.Student_ID = s.Student_ID
       LEFT JOIN course c ON e.Course_ID = c.Course_ID
       ORDER BY e.Enroll_ID DESC`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

// GET enrolled students for a specific course (admin + teacher)
router.get('/by-course/:courseId', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT e.Enroll_ID, e.Student_ID, e.Course_ID, e.Semester, e.Year,
              s.Name AS Student_Name, s.Email
       FROM enrollment e
       JOIN student s ON e.Student_ID = s.Student_ID
       WHERE e.Course_ID = ?
       ORDER BY s.Name`, [req.params.courseId]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.get('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM enrollment WHERE Enroll_ID = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Not found.' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.post('/', isAuthenticated, isAdmin, async (req, res) => {
  const { Student_ID, Course_ID, Semester, Year } = req.body;
  if (!Student_ID || !Course_ID) return res.status(400).json({ error: 'Student_ID and Course_ID required.' });
  try {
    const [existing] = await pool.execute(
      'SELECT Enroll_ID FROM enrollment WHERE Student_ID=? AND Course_ID=?',
      [Student_ID, Course_ID]
    );
    if (existing.length > 0) return res.status(409).json({ error: 'Student already enrolled in this course.' });
    const [result] = await pool.execute(
      'INSERT INTO enrollment (Student_ID, Course_ID, Semester, Year) VALUES (?, ?, ?, ?)',
      [Student_ID, Course_ID, Semester || null, Year || null]
    );
    const [newRow] = await pool.execute(
      `SELECT e.*, s.Name AS Student_Name, c.Course_Name FROM enrollment e
       LEFT JOIN student s ON e.Student_ID = s.Student_ID
       LEFT JOIN course c ON e.Course_ID = c.Course_ID
       WHERE e.Enroll_ID = ?`, [result.insertId]
    );
    res.status(201).json(newRow[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.put('/:id', isAuthenticated, isAdmin, async (req, res) => {
  const { Student_ID, Course_ID, Semester, Year } = req.body;
  if (!Student_ID || !Course_ID) return res.status(400).json({ error: 'Student_ID and Course_ID required.' });
  try {
    const [result] = await pool.execute(
      'UPDATE enrollment SET Student_ID=?, Course_ID=?, Semester=?, Year=? WHERE Enroll_ID=?',
      [Student_ID, Course_ID, Semester || null, Year || null, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Enrollment not found.' });
    const [updated] = await pool.execute(
      `SELECT e.*, s.Name AS Student_Name, c.Course_Name FROM enrollment e
       LEFT JOIN student s ON e.Student_ID = s.Student_ID
       LEFT JOIN course c ON e.Course_ID = c.Course_ID
       WHERE e.Enroll_ID = ?`, [req.params.id]
    );
    res.json(updated[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM enrollment WHERE Enroll_ID = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Enrollment not found.' });
    res.json({ message: 'Enrollment deleted.' });
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

module.exports = router;
