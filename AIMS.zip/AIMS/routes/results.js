// routes/results.js
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { isAuthenticated, isAdmin, isAdminOrTeacher } = require('../middleware/auth');

// GET all results (optionally filtered by course)
router.get('/', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const { course_id } = req.query;
    let sql = `SELECT r.*, s.Name AS Student_Name, c.Course_Name FROM result r
               LEFT JOIN student s ON r.Student_ID = s.Student_ID
               LEFT JOIN course c ON r.Course_ID = c.Course_ID`;
    const params = [];
    if (course_id) { sql += ' WHERE r.Course_ID = ?'; params.push(course_id); }
    sql += ' ORDER BY r.Year DESC, r.Semester, c.Course_Name, s.Name';
    const [rows] = await pool.execute(sql, params);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

// GET student's own results
router.get('/my', isAuthenticated, async (req, res) => {
  if (req.session.user.role !== 'student')
    return res.status(403).json({ error: 'Access denied.' });
  try {
    const [rows] = await pool.execute(
      `SELECT r.*, c.Course_Name, c.Credits FROM result r
       LEFT JOIN course c ON r.Course_ID = c.Course_ID
       WHERE r.Student_ID = ? ORDER BY r.Year DESC, r.Semester`,
      [req.session.user.reference_id]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.get('/:id', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM result WHERE Result_ID = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Not found.' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.post('/', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  const { Student_ID, Course_ID, Grade, GPA, Semester, Year } = req.body;
  if (!Student_ID || !Course_ID || !Grade)
    return res.status(400).json({ error: 'Student_ID, Course_ID and Grade are required.' });
  try {
    // Validate student is enrolled in this course
    const [enrolled] = await pool.execute(
      'SELECT Enroll_ID FROM enrollment WHERE Student_ID=? AND Course_ID=?',
      [Student_ID, Course_ID]
    );
    if (enrolled.length === 0)
      return res.status(400).json({ error: 'Student is not enrolled in this course.' });

    // Check for duplicate result
    const [dup] = await pool.execute(
      'SELECT Result_ID FROM result WHERE Student_ID=? AND Course_ID=? AND Semester=? AND Year=?',
      [Student_ID, Course_ID, Semester || null, Year || null]
    );
    if (dup.length > 0)
      return res.status(409).json({ error: 'Result already exists for this student/course/semester.' });

    const [result] = await pool.execute(
      'INSERT INTO result (Student_ID, Course_ID, Grade, GPA, Semester, Year) VALUES (?, ?, ?, ?, ?, ?)',
      [Student_ID, Course_ID, Grade, GPA || null, Semester || null, Year || null]
    );
    const [newRow] = await pool.execute(
      `SELECT r.*, s.Name AS Student_Name, c.Course_Name FROM result r
       LEFT JOIN student s ON r.Student_ID = s.Student_ID
       LEFT JOIN course c ON r.Course_ID = c.Course_ID
       WHERE r.Result_ID = ?`, [result.insertId]
    );
    res.status(201).json(newRow[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.put('/:id', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  const { Student_ID, Course_ID, Grade, GPA, Semester, Year } = req.body;
  if (!Student_ID || !Course_ID || !Grade)
    return res.status(400).json({ error: 'Student_ID, Course_ID and Grade are required.' });
  try {
    const [result] = await pool.execute(
      'UPDATE result SET Student_ID=?, Course_ID=?, Grade=?, GPA=?, Semester=?, Year=? WHERE Result_ID=?',
      [Student_ID, Course_ID, Grade, GPA || null, Semester || null, Year || null, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Result not found.' });
    const [updated] = await pool.execute(
      `SELECT r.*, s.Name AS Student_Name, c.Course_Name FROM result r
       LEFT JOIN student s ON r.Student_ID = s.Student_ID
       LEFT JOIN course c ON r.Course_ID = c.Course_ID
       WHERE r.Result_ID = ?`, [req.params.id]
    );
    res.json(updated[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM result WHERE Result_ID = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Result not found.' });
    res.json({ message: 'Result deleted.' });
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

module.exports = router;
