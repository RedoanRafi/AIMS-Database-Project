const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { isAuthenticated, isAdmin } = require('../middleware/auth');

router.get('/', isAuthenticated, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM department ORDER BY Dept_ID');
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.get('/:id', isAuthenticated, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM department WHERE Dept_ID = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Not found.' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.post('/', isAuthenticated, isAdmin, async (req, res) => {
  const { Dept_Name, Office_Location, Budget } = req.body;
  if (!Dept_Name) return res.status(400).json({ error: 'Department name is required.' });
  try {
    const [result] = await pool.execute(
      'INSERT INTO department (Dept_Name, Office_Location, Budget) VALUES (?, ?, ?)',
      [Dept_Name, Office_Location || null, Budget || null]
    );
    const [newRow] = await pool.execute('SELECT * FROM department WHERE Dept_ID = ?', [result.insertId]);
    res.status(201).json(newRow[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.put('/:id', isAuthenticated, isAdmin, async (req, res) => {
  const { Dept_Name, Office_Location, Budget } = req.body;
  if (!Dept_Name) return res.status(400).json({ error: 'Department name is required.' });
  try {
    const [result] = await pool.execute(
      'UPDATE department SET Dept_Name=?, Office_Location=?, Budget=? WHERE Dept_ID=?',
      [Dept_Name, Office_Location || null, Budget || null, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Department not found.' });
    const [updated] = await pool.execute('SELECT * FROM department WHERE Dept_ID = ?', [req.params.id]);
    res.json(updated[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM department WHERE Dept_ID = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Department not found.' });
    res.json({ message: 'Department deleted.' });
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

module.exports = router;
