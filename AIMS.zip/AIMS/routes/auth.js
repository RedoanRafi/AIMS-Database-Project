const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const pool = require('../config/db');

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password)
    return res.status(400).json({ error: 'Username and password are required.' });

  try {
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE username = ?', [username]
    );
    if (rows.length === 0)
      return res.status(401).json({ error: 'Invalid username or password.' });

    const user = rows[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match)
      return res.status(401).json({ error: 'Invalid username or password.' });

    req.session.user = {
      id: user.user_id,
      username: user.username,
      role: user.role,
      reference_id: user.reference_id,
      name: user.full_name
    };

    res.json({
      message: 'Login successful',
      user: {
        id: user.user_id,
        username: user.username,
        role: user.role,
        name: user.full_name
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error.' });
  }
});

// POST /api/auth/register/student
router.post('/register/student', async (req, res) => {
  const { username, password, name, email, phone, address, gender, dob, admission_year, dept_id } = req.body;
  if (!username || !password || !name || !email)
    return res.status(400).json({ error: 'Username, password, name and email are required.' });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Check username uniqueness
    const [existing] = await conn.execute('SELECT user_id FROM users WHERE username = ?', [username]);
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(409).json({ error: 'Username already taken.' });
    }

    // Insert student record
    const [studentResult] = await conn.execute(
      `INSERT INTO student (Name, Email, Phone, Address, Gender, Date_of_Birth, Admission_Year, Dept_ID)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [name, email, phone || null, address || null, gender || null, dob || null, admission_year || new Date().getFullYear(), dept_id || null]
    );
    const studentId = studentResult.insertId;

    // Hash password and create user
    const hash = await bcrypt.hash(password, 10);
    await conn.execute(
      `INSERT INTO users (username, password_hash, role, reference_id, full_name) VALUES (?, ?, 'student', ?, ?)`,
      [username, hash, studentId, name]
    );

    await conn.commit();
    res.status(201).json({ message: 'Student registered successfully. You can now log in.' });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    if (err.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: 'Email already registered.' });
    res.status(500).json({ error: 'Server error.' });
  } finally {
    conn.release();
  }
});

// POST /api/auth/register/teacher
router.post('/register/teacher', async (req, res) => {
  const { username, password, name, email, phone, designation, dept_id } = req.body;
  if (!username || !password || !name || !email)
    return res.status(400).json({ error: 'Username, password, name and email are required.' });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [existing] = await conn.execute('SELECT user_id FROM users WHERE username = ?', [username]);
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(409).json({ error: 'Username already taken.' });
    }

    const [teacherResult] = await conn.execute(
      `INSERT INTO teacher (Name, Email, Phone, Designation, Dept_ID) VALUES (?, ?, ?, ?, ?)`,
      [name, email, phone || null, designation || 'Lecturer', dept_id || null]
    );
    const teacherId = teacherResult.insertId;

    const hash = await bcrypt.hash(password, 10);
    await conn.execute(
      `INSERT INTO users (username, password_hash, role, reference_id, full_name) VALUES (?, ?, 'teacher', ?, ?)`,
      [username, hash, teacherId, name]
    );

    await conn.commit();
    res.status(201).json({ message: 'Teacher registered successfully. You can now log in.' });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    if (err.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: 'Email already registered.' });
    res.status(500).json({ error: 'Server error.' });
  } finally {
    conn.release();
  }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ message: 'Logged out successfully.' });
  });
});

// GET /api/auth/me
router.get('/me', (req, res) => {
  if (req.session && req.session.user) {
    res.json({ user: req.session.user });
  } else {
    res.status(401).json({ error: 'Not authenticated.' });
  }
});

module.exports = router;
