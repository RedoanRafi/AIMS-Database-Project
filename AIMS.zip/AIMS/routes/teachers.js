const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { isAuthenticated, isAdmin, isAdminOrTeacher } = require('../middleware/auth');

// GET /api/teachers
router.get('/', isAuthenticated, isAdminOrTeacher, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT t.*, d.Dept_Name FROM teacher t
       LEFT JOIN department d ON t.Dept_ID = d.Dept_ID
       ORDER BY t.Teacher_ID DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// GET /api/teachers/my - Teacher views own profile
router.get('/my', isAuthenticated, async (req, res) => {
  if (req.session.user.role !== 'teacher')
    return res.status(403).json({ error: 'Access denied.' });
  try {
    const [rows] = await pool.execute(
      `SELECT t.*, d.Dept_Name FROM teacher t
       LEFT JOIN department d ON t.Dept_ID = d.Dept_ID
       WHERE t.Teacher_ID = ?`,
      [req.session.user.reference_id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Profile not found.' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// GET /api/teachers/:id
router.get('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT t.*, d.Dept_Name FROM teacher t
       LEFT JOIN department d ON t.Dept_ID = d.Dept_ID
       WHERE t.Teacher_ID = ?`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Teacher not found.' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// POST /api/teachers
router.post('/', isAuthenticated, isAdmin, async (req, res) => {
  const { Name, Email, Phone, Designation, Salary, Dept_ID } = req.body;
  if (!Name || !Email) return res.status(400).json({ error: 'Name and Email are required.' });
  try {
    const [result] = await pool.execute(
      `INSERT INTO teacher (Name, Email, Phone, Designation, Salary, Dept_ID) VALUES (?, ?, ?, ?, ?, ?)`,
      [Name, Email, Phone || null, Designation || null, Salary || null, Dept_ID || null]
    );
    const [newRow] = await pool.execute('SELECT * FROM teacher WHERE Teacher_ID = ?', [result.insertId]);
    res.status(201).json(newRow[0]);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Email already exists.' });
    res.status(500).json({ error: 'Server error.' });
  }
});

// PUT /api/teachers/:id
router.put('/:id', isAuthenticated, isAdmin, async (req, res) => {
  const { Name, Email, Phone, Designation, Salary, Dept_ID } = req.body;
  if (!Name || !Email) return res.status(400).json({ error: 'Name and Email are required.' });
  try {
    const [result] = await pool.execute(
      `UPDATE teacher SET Name=?, Email=?, Phone=?, Designation=?, Salary=?, Dept_ID=? WHERE Teacher_ID=?`,
      [Name, Email, Phone || null, Designation || null, Salary || null, Dept_ID || null, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Teacher not found.' });
    const [updated] = await pool.execute('SELECT * FROM teacher WHERE Teacher_ID = ?', [req.params.id]);
    res.json(updated[0]);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Email already exists.' });
    res.status(500).json({ error: 'Server error.' });
  }
});

// DELETE /api/teachers/:id
router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM teacher WHERE Teacher_ID = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Teacher not found.' });
    res.json({ message: 'Teacher deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
