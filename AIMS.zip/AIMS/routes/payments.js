const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { isAuthenticated, isAdmin } = require('../middleware/auth');

router.get('/', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT p.*, s.Name AS Student_Name FROM payment p
       LEFT JOIN student s ON p.Student_ID = s.Student_ID
       ORDER BY p.Payment_ID DESC`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.get('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM payment WHERE Payment_ID = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Not found.' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.post('/', isAuthenticated, isAdmin, async (req, res) => {
  const { Student_ID, Amount, Payment_Date, Status, Method } = req.body;
  if (!Student_ID || !Amount) return res.status(400).json({ error: 'Student_ID and Amount required.' });
  try {
    const [result] = await pool.execute(
      'INSERT INTO payment (Student_ID, Amount, Payment_Date, Status, Method) VALUES (?, ?, ?, ?, ?)',
      [Student_ID, Amount, Payment_Date || null, Status || 'Pending', Method || null]
    );
    const [newRow] = await pool.execute(
      `SELECT p.*, s.Name AS Student_Name FROM payment p
       LEFT JOIN student s ON p.Student_ID = s.Student_ID
       WHERE p.Payment_ID = ?`, [result.insertId]
    );
    res.status(201).json(newRow[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.put('/:id', isAuthenticated, isAdmin, async (req, res) => {
  const { Student_ID, Amount, Payment_Date, Status, Method } = req.body;
  if (!Student_ID || !Amount) return res.status(400).json({ error: 'Student_ID and Amount required.' });
  try {
    const [result] = await pool.execute(
      'UPDATE payment SET Student_ID=?, Amount=?, Payment_Date=?, Status=?, Method=? WHERE Payment_ID=?',
      [Student_ID, Amount, Payment_Date || null, Status || 'Pending', Method || null, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Payment not found.' });
    const [updated] = await pool.execute(
      `SELECT p.*, s.Name AS Student_Name FROM payment p
       LEFT JOIN student s ON p.Student_ID = s.Student_ID
       WHERE p.Payment_ID = ?`, [req.params.id]
    );
    res.json(updated[0]);
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM payment WHERE Payment_ID = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Payment not found.' });
    res.json({ message: 'Payment record deleted.' });
  } catch (err) { res.status(500).json({ error: 'Server error.' }); }
});

module.exports = router;
