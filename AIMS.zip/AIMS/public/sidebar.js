// Shared sidebar HTML generator for admin pages
function getAdminSidebar(activePage) {
  const links = [
    { href: 'dashboard.html', icon: 'fa-house', label: 'Dashboard' },
    { href: 'students.html', icon: 'fa-user-graduate', label: 'Students' },
    { href: 'teachers.html', icon: 'fa-chalkboard-user', label: 'Teachers' },
    { href: 'departments.html', icon: 'fa-building', label: 'Departments' },
    { href: 'courses.html', icon: 'fa-book-open', label: 'Courses' },
    { href: 'enrollment.html', icon: 'fa-clipboard-list', label: 'Enrollment' },
    { href: 'results.html', icon: 'fa-square-poll-vertical', label: 'Results' },
    { href: 'payments.html', icon: 'fa-file-invoice-dollar', label: 'Payments' },
    { href: 'attendance.html', icon: 'fa-calendar-check', label: 'Attendance' },
  ];
  return `
    <div class="sidebar-header">
      <div class="logo-text"><i class="fa-solid fa-graduation-cap"></i> AIMS</div>
    </div>
    <nav class="sidebar-menu">
      ${links.map(l => `
        <a href="${l.href}" class="menu-item ${activePage === l.href ? 'active' : ''}">
          <i class="fa-solid ${l.icon}"></i><span>${l.label}</span>
        </a>`).join('')}
    </nav>`;
}
