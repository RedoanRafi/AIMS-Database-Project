// ============================================================
// AIMS - Frontend Application JavaScript
// ============================================================

const API = '/api';

// -------- UTILITIES --------

function toast(message, type = 'success') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', info: 'fa-circle-info' };
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i><span>${message}</span>`;
  container.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

async function apiFetch(endpoint, options = {}) {
  try {
    const res = await fetch(API + endpoint, {
      headers: { 'Content-Type': 'application/json', ...options.headers },
      credentials: 'include',
      ...options
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  } catch (err) { throw err; }
}

function getUser() {
  const u = sessionStorage.getItem('aimsUser');
  return u ? JSON.parse(u) : null;
}

function requireAuth(allowedRoles) {
  const user = getUser();
  if (!user) { window.location.href = '/index.html'; return null; }
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    toast('Access denied.', 'error');
    redirectByRole(user.role);
    return null;
  }
  return user;
}

function redirectByRole(role) {
  const routes = { admin: '/dashboard.html', teacher: '/teacher-portal.html', student: '/student-portal.html' };
  window.location.href = routes[role] || '/index.html';
}

// -------- SIDEBAR & NAV --------

function initNav() {
  const user = getUser();
  if (!user) return;
  const nameEl = document.getElementById('userName');
  const avatarEl = document.getElementById('userAvatar');
  if (nameEl) nameEl.textContent = user.name;
  if (avatarEl) avatarEl.textContent = user.name ? user.name.charAt(0).toUpperCase() : 'U';

  const toggle = document.getElementById('sidebar-toggle');
  const sidebar = document.getElementById('sidebar');
  if (toggle && sidebar) toggle.addEventListener('click', () => sidebar.classList.toggle('collapsed'));

  const page = window.location.pathname.split('/').pop() || 'dashboard.html';
  document.querySelectorAll('.menu-item').forEach(item => {
    const href = item.getAttribute('href')?.split('/').pop();
    if (href === page) item.classList.add('active');
    else item.classList.remove('active');
  });

  // Hide admin-only elements for non-admins
  if (user.role !== 'admin') {
    document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'none');
  }

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      await apiFetch('/auth/logout', { method: 'POST' }).catch(() => {});
      sessionStorage.removeItem('aimsUser');
      window.location.href = '/index.html';
    });
  }
}

// -------- MODAL HELPERS --------

let currentEditId = null;

function openModal(title, id = null) {
  currentEditId = id;
  const modal = document.getElementById('genericModal');
  const titleEl = document.getElementById('modalTitle');
  if (titleEl) titleEl.textContent = title;
  if (modal) modal.classList.add('show');
}

function closeModal() {
  const modal = document.getElementById('genericModal');
  if (modal) modal.classList.remove('show');
  const form = document.getElementById('modalForm');
  if (form) form.reset();
  currentEditId = null;
}

document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('genericModal');
  if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  const modal2 = document.getElementById('enrolledModal');
  if (modal2) modal2.addEventListener('click', e => { if (e.target === modal2) closeEnrolledModal(); });
});

// -------- SEARCH FILTER --------

function initSearch() {
  const searchInput = document.querySelector('.searchInput');
  if (searchInput) {
    searchInput.addEventListener('keyup', function () {
      const val = this.value.toLowerCase();
      document.querySelectorAll('.table-container tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(val) ? '' : 'none';
      });
    });
  }
}

// -------- LOGIN PAGE --------

async function initLogin() {
  try {
    const { user } = await apiFetch('/auth/me');
    sessionStorage.setItem('aimsUser', JSON.stringify(user));
    redirectByRole(user.role);
    return;
  } catch (e) {}

  let selectedRole = 'admin';
  document.querySelectorAll('.role-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      selectedRole = tab.dataset.role;
    });
  });

  const form = document.getElementById('loginForm');
  if (!form) return;
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const errorMsg = document.getElementById('errorMsg');
    errorMsg.textContent = '';
    try {
      const data = await apiFetch('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
      sessionStorage.setItem('aimsUser', JSON.stringify(data.user));
      redirectByRole(data.user.role);
    } catch (err) {
      errorMsg.textContent = err.message;
      errorMsg.style.display = 'block';
    }
  });
}

// -------- REGISTER PAGE --------

async function initRegister() {
  try {
    const depts = await apiFetch('/departments');
    const deptSelects = document.querySelectorAll('.dept-select');
    deptSelects.forEach(sel => {
      depts.forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.Dept_ID;
        opt.textContent = d.Dept_Name;
        sel.appendChild(opt);
      });
    });
  } catch (e) {}

  let selectedRole = 'student';
  document.querySelectorAll('.role-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      selectedRole = tab.dataset.role;
      document.getElementById('studentFields').style.display = selectedRole === 'student' ? '' : 'none';
      document.getElementById('teacherFields').style.display = selectedRole === 'teacher' ? '' : 'none';
    });
  });

  const form = document.getElementById('registerForm');
  if (!form) return;
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const errorMsg = document.getElementById('errorMsg');
    errorMsg.textContent = '';
    const data = Object.fromEntries(new FormData(form));
    try {
      const res = await apiFetch(`/auth/register/${selectedRole}`, { method: 'POST', body: JSON.stringify(data) });
      toast(res.message, 'success');
      setTimeout(() => window.location.href = '/index.html', 1500);
    } catch (err) {
      errorMsg.textContent = err.message;
      errorMsg.style.display = 'block';
    }
  });
}

// -------- DASHBOARD PAGE --------

async function initDashboard() {
  const user = requireAuth(['admin']);
  if (!user) return;
  initNav();
  try {
    const stats = await apiFetch('/stats');
    document.getElementById('statStudents').textContent = stats.students.toLocaleString();
    document.getElementById('statTeachers').textContent = stats.teachers.toLocaleString();
    document.getElementById('statCourses').textContent = stats.courses.toLocaleString();
    document.getElementById('statRevenue').textContent = '৳' + Number(stats.revenue).toLocaleString();
  } catch (err) { toast('Could not load stats: ' + err.message, 'error'); }
}

// -------- STUDENTS PAGE --------

let allDepts = [];

async function initStudents() {
  const user = requireAuth(['admin', 'teacher']);
  if (!user) return;
  initNav();
  initSearch();
  try {
    allDepts = await apiFetch('/departments');
    const deptSel = document.getElementById('deptSelect');
    if (deptSel) {
      allDepts.forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.Dept_ID;
        opt.textContent = d.Dept_Name;
        deptSel.appendChild(opt);
      });
    }
  } catch (e) {}
  await loadStudents();
  if (user.role === 'teacher') document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'none');
  const form = document.getElementById('modalForm');
  if (form && user.role === 'admin') {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form));
      try {
        if (currentEditId) {
          await apiFetch(`/students/${currentEditId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Student updated!');
        } else {
          await apiFetch('/students', { method: 'POST', body: JSON.stringify(body) });
          toast('Student added!');
        }
        closeModal();
        await loadStudents();
      } catch (err) { toast(err.message, 'error'); }
    });
  }
}

async function loadStudents() {
  const tbody = document.getElementById('studentsBody');
  if (!tbody) return;
  const user = getUser();
  tbody.innerHTML = '<tr><td colspan="6" class="skeleton" style="height:40px"></td></tr>';
  try {
    const students = await apiFetch('/students');
    if (students.length === 0) {
      tbody.innerHTML = '<tr class="no-data-row"><td colspan="6"><i class="fa-solid fa-inbox"></i> No students found.</td></tr>';
      return;
    }
    tbody.innerHTML = students.map(s => `
      <tr>
        <td>${s.Student_ID}</td>
        <td>${s.Name}</td>
        <td>${s.Dept_Name || '—'}</td>
        <td>${s.Email}</td>
        <td>${s.Phone || '—'}</td>
        <td><div class="action-btns">
          ${user.role === 'admin' ? `
            <button class="btn-edit" onclick="editStudent(${s.Student_ID})"><i class="fa-solid fa-pen"></i></button>
            <button class="btn-danger" onclick="deleteStudent(${s.Student_ID})"><i class="fa-solid fa-trash"></i></button>
          ` : '<span style="color:#94a3b8;font-size:0.8rem">View only</span>'}
        </div></td>
      </tr>`).join('');
  } catch (err) {
    toast(err.message, 'error');
    tbody.innerHTML = '<tr class="no-data-row"><td colspan="6">Error loading data.</td></tr>';
  }
}

async function editStudent(id) {
  try {
    const s = await apiFetch(`/students/${id}`);
    document.getElementById('sName').value = s.Name;
    document.getElementById('sEmail').value = s.Email;
    document.getElementById('sPhone').value = s.Phone || '';
    document.getElementById('sAddress').value = s.Address || '';
    document.getElementById('sGender').value = s.Gender || '';
    document.getElementById('sDob').value = s.Date_of_Birth ? s.Date_of_Birth.split('T')[0] : '';
    document.getElementById('sAdmYear').value = s.Admission_Year || '';
    document.getElementById('deptSelect').value = s.Dept_ID || '';
    openModal('Edit Student', id);
  } catch (err) { toast(err.message, 'error'); }
}

async function deleteStudent(id) {
  if (!confirm('Are you sure you want to delete this student? This cannot be undone.')) return;
  try {
    await apiFetch(`/students/${id}`, { method: 'DELETE' });
    toast('Student deleted.');
    await loadStudents();
  } catch (err) { toast(err.message, 'error'); }
}

// -------- TEACHERS PAGE --------

async function initTeachers() {
  const user = requireAuth(['admin']);
  if (!user) return;
  initNav();
  initSearch();
  try {
    allDepts = await apiFetch('/departments');
    const deptSel = document.getElementById('deptSelect');
    if (deptSel) {
      allDepts.forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.Dept_ID;
        opt.textContent = d.Dept_Name;
        deptSel.appendChild(opt);
      });
    }
  } catch (e) {}
  await loadTeachers();
  const form = document.getElementById('modalForm');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form));
      try {
        if (currentEditId) {
          await apiFetch(`/teachers/${currentEditId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Teacher updated!');
        } else {
          await apiFetch('/teachers', { method: 'POST', body: JSON.stringify(body) });
          toast('Teacher added!');
        }
        closeModal();
        await loadTeachers();
      } catch (err) { toast(err.message, 'error'); }
    });
  }
}

async function loadTeachers() {
  const tbody = document.getElementById('teachersBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="6" class="skeleton" style="height:40px"></td></tr>';
  try {
    const teachers = await apiFetch('/teachers');
    if (teachers.length === 0) {
      tbody.innerHTML = '<tr class="no-data-row"><td colspan="6"><i class="fa-solid fa-inbox"></i> No teachers found.</td></tr>';
      return;
    }
    tbody.innerHTML = teachers.map(t => `
      <tr>
        <td>${t.Teacher_ID}</td>
        <td>${t.Name}</td>
        <td>${t.Designation || '—'}</td>
        <td>${t.Dept_Name || '—'}</td>
        <td>${t.Email}</td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="editTeacher(${t.Teacher_ID})"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-danger" onclick="deleteTeacher(${t.Teacher_ID})"><i class="fa-solid fa-trash"></i></button>
        </div></td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function editTeacher(id) {
  try {
    const t = await apiFetch(`/teachers/${id}`);
    document.getElementById('tName').value = t.Name;
    document.getElementById('tEmail').value = t.Email;
    document.getElementById('tPhone').value = t.Phone || '';
    document.getElementById('tDesignation').value = t.Designation || '';
    document.getElementById('tSalary').value = t.Salary || '';
    document.getElementById('deptSelect').value = t.Dept_ID || '';
    openModal('Edit Teacher', id);
  } catch (err) { toast(err.message, 'error'); }
}

async function deleteTeacher(id) {
  if (!confirm('Delete this teacher?')) return;
  try {
    await apiFetch(`/teachers/${id}`, { method: 'DELETE' });
    toast('Teacher deleted.');
    await loadTeachers();
  } catch (err) { toast(err.message, 'error'); }
}

// -------- DEPARTMENTS PAGE --------

async function initDepartments() {
  const user = requireAuth(['admin']);
  if (!user) return;
  initNav();
  initSearch();
  await loadDepartments();
  const form = document.getElementById('modalForm');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form));
      try {
        if (currentEditId) {
          await apiFetch(`/departments/${currentEditId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Department updated!');
        } else {
          await apiFetch('/departments', { method: 'POST', body: JSON.stringify(body) });
          toast('Department added!');
        }
        closeModal();
        await loadDepartments();
      } catch (err) { toast(err.message, 'error'); }
    });
  }
}

async function loadDepartments() {
  const tbody = document.getElementById('deptsBody');
  if (!tbody) return;
  try {
    const depts = await apiFetch('/departments');
    if (depts.length === 0) {
      tbody.innerHTML = '<tr class="no-data-row"><td colspan="4">No departments found.</td></tr>';
      return;
    }
    tbody.innerHTML = depts.map(d => `
      <tr>
        <td>${d.Dept_ID}</td>
        <td>${d.Dept_Name}</td>
        <td>${d.Office_Location || '—'}</td>
        <td>৳${Number(d.Budget || 0).toLocaleString()}</td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="editDept(${d.Dept_ID})"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-danger" onclick="deleteDept(${d.Dept_ID})"><i class="fa-solid fa-trash"></i></button>
        </div></td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function editDept(id) {
  try {
    const d = await apiFetch(`/departments/${id}`);
    document.getElementById('dName').value = d.Dept_Name;
    document.getElementById('dLocation').value = d.Office_Location || '';
    document.getElementById('dBudget').value = d.Budget || '';
    openModal('Edit Department', id);
  } catch (err) { toast(err.message, 'error'); }
}

async function deleteDept(id) {
  if (!confirm('Delete this department?')) return;
  try {
    await apiFetch(`/departments/${id}`, { method: 'DELETE' });
    toast('Department deleted.');
    await loadDepartments();
  } catch (err) { toast(err.message, 'error'); }
}

// ====================================================================
// -------- COURSES PAGE --------
// Admin assigns teacher + views enrolled students per course
// ====================================================================

let _allCourses = [];

async function initCourses() {
  const user = requireAuth(['admin', 'teacher']);
  if (!user) return;
  initNav();
  initSearch();

  // Populate dropdowns in the add/edit modal
  try {
    const [depts, teachers] = await Promise.all([apiFetch('/departments'), apiFetch('/teachers')]);
    const deptSel = document.getElementById('cDept');
    const teachSel = document.getElementById('cTeacher');
    if (deptSel) depts.forEach(d => deptSel.appendChild(new Option(d.Dept_Name, d.Dept_ID)));
    if (teachSel) teachers.forEach(t => teachSel.appendChild(new Option(`${t.Name} (${t.Designation || 'Teacher'})`, t.Teacher_ID)));
  } catch (e) {}

  await loadCourses();

  const form = document.getElementById('modalForm');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form));
      try {
        if (currentEditId) {
          await apiFetch(`/courses/${currentEditId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Course updated!');
        } else {
          await apiFetch('/courses', { method: 'POST', body: JSON.stringify(body) });
          toast('Course created!');
        }
        closeModal();
        await loadCourses();
      } catch (err) { toast(err.message, 'error'); }
    });
  }
}

async function loadCourses() {
  const tbody = document.getElementById('coursesBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="7" class="skeleton" style="height:40px"></td></tr>';
  try {
    _allCourses = await apiFetch('/courses');
    const user = getUser();
    if (_allCourses.length === 0) {
      tbody.innerHTML = '<tr class="no-data-row"><td colspan="7"><i class="fa-solid fa-inbox"></i> No courses found.</td></tr>';
      return;
    }
    tbody.innerHTML = _allCourses.map(c => `
      <tr>
        <td><strong>${c.Course_ID}</strong></td>
        <td>${c.Course_Name}</td>
        <td><span style="background:var(--light-blue);color:var(--primary-blue);padding:2px 8px;border-radius:12px;font-size:.85rem">${c.Credits} cr</span></td>
        <td>${c.Dept_Name || '—'}</td>
        <td>
          ${c.Teacher_Name
            ? `<span style="display:flex;align-items:center;gap:.4rem"><i class="fa-solid fa-chalkboard-user" style="color:var(--primary-green)"></i>${c.Teacher_Name}</span>`
            : `<span style="color:#f59e0b;font-size:.85rem"><i class="fa-solid fa-triangle-exclamation"></i> Unassigned</span>`}
        </td>
        <td>
          <button onclick="viewEnrolledStudents('${c.Course_ID}', '${c.Course_Name}')" style="background:none;border:none;cursor:pointer;color:var(--primary-blue);font-weight:600;font-size:.9rem">
            <i class="fa-solid fa-users"></i> ${c.enrolled_count || 0}
          </button>
        </td>
        <td><div class="action-btns">
          ${user.role === 'admin' ? `
            <button class="btn-edit" onclick="editCourse('${c.Course_ID}')"><i class="fa-solid fa-pen"></i></button>
            <button class="btn-danger" onclick="deleteCourse('${c.Course_ID}')"><i class="fa-solid fa-trash"></i></button>
          ` : '<span style="color:#94a3b8;font-size:.8rem">View only</span>'}
        </div></td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function editCourse(id) {
  try {
    const c = await apiFetch(`/courses/${id}`);
    document.getElementById('cId').value = c.Course_ID;
    document.getElementById('cId').disabled = true;
    document.getElementById('cName').value = c.Course_Name;
    document.getElementById('cCredits').value = c.Credits;
    document.getElementById('cDept').value = c.Dept_ID || '';
    document.getElementById('cTeacher').value = c.Teacher_ID || '';
    openModal('Edit Course — Assign Teacher', id);
  } catch (err) { toast(err.message, 'error'); }
}

async function deleteCourse(id) {
  if (!confirm(`Delete course ${id}? This will also remove all enrollment, attendance and result records for this course.`)) return;
  try {
    await apiFetch(`/courses/${id}`, { method: 'DELETE' });
    toast('Course deleted.');
    await loadCourses();
  } catch (err) { toast(err.message, 'error'); }
}

// View enrolled students for a course
async function viewEnrolledStudents(courseId, courseName) {
  const modal = document.getElementById('enrolledModal');
  const title = document.getElementById('enrolledModalTitle');
  const list = document.getElementById('enrolledStudentsList');
  const statsBar = document.getElementById('enrolledStatsBar');
  if (!modal) return;

  title.innerHTML = `<i class="fa-solid fa-users" style="color:var(--primary-blue)"></i> ${courseName} <small style="color:var(--text-light);font-weight:400">(${courseId})</small>`;
  list.innerHTML = '<div class="skeleton" style="height:60px;border-radius:8px;margin-bottom:.5rem"></div>';
  statsBar.innerHTML = '';
  modal.classList.add('show');

  try {
    const [students, attStats] = await Promise.all([
      apiFetch(`/enrollment/by-course/${courseId}`),
      apiFetch('/attendance/stats')
    ]);
    const courseAtt = attStats.find(s => s.Course_ID === courseId);

    // Stats bar
    const totalClasses = courseAtt?.total_classes || 0;
    const presentCount = courseAtt?.present_count || 0;
    const absentCount = courseAtt?.absent_count || 0;
    const lateCount = courseAtt?.late_count || 0;
    statsBar.innerHTML = `
      <div style="text-align:center"><div style="font-size:1.3rem;font-weight:700;color:var(--primary-blue)">${students.length}</div><div style="font-size:.78rem;color:var(--text-light)">Enrolled</div></div>
      <div style="text-align:center"><div style="font-size:1.3rem;font-weight:700;color:var(--text-dark)">${totalClasses}</div><div style="font-size:.78rem;color:var(--text-light)">Classes Held</div></div>
      <div style="text-align:center"><div style="font-size:1.3rem;font-weight:700;color:var(--primary-green)">${presentCount}</div><div style="font-size:.78rem;color:var(--text-light)">Present Records</div></div>
      <div style="text-align:center"><div style="font-size:1.3rem;font-weight:700;color:#ef4444">${absentCount}</div><div style="font-size:.78rem;color:var(--text-light)">Absent Records</div></div>
      ${lateCount > 0 ? `<div style="text-align:center"><div style="font-size:1.3rem;font-weight:700;color:#f59e0b">${lateCount}</div><div style="font-size:.78rem;color:var(--text-light)">Late Records</div></div>` : ''}
    `;

    if (students.length === 0) {
      list.innerHTML = `<div style="text-align:center;padding:2rem;color:var(--text-light)"><i class="fa-solid fa-user-slash" style="font-size:2rem;margin-bottom:.5rem"></i><br>No students enrolled in this course yet.<br><small>Use the Enrollment page to add students.</small></div>`;
      return;
    }

    list.innerHTML = `
      <table style="width:100%;border-collapse:collapse">
        <thead><tr style="background:var(--bg-color)">
          <th style="padding:.6rem .8rem;text-align:left;font-size:.82rem;color:var(--text-light);font-weight:600">#</th>
          <th style="padding:.6rem .8rem;text-align:left;font-size:.82rem;color:var(--text-light);font-weight:600">Student</th>
          <th style="padding:.6rem .8rem;text-align:left;font-size:.82rem;color:var(--text-light);font-weight:600">Email</th>
          <th style="padding:.6rem .8rem;text-align:left;font-size:.82rem;color:var(--text-light);font-weight:600">Semester</th>
        </tr></thead>
        <tbody>
          ${students.map((s, i) => `
            <tr style="border-top:1px solid var(--border-color)">
              <td style="padding:.6rem .8rem;color:var(--text-light)">${i + 1}</td>
              <td style="padding:.6rem .8rem;font-weight:500">${s.Student_Name}</td>
              <td style="padding:.6rem .8rem;font-size:.88rem;color:var(--text-light)">${s.Email}</td>
              <td style="padding:.6rem .8rem;font-size:.88rem">${s.Semester || '—'} ${s.Year || ''}</td>
            </tr>`).join('')}
        </tbody>
      </table>`;
  } catch (err) {
    list.innerHTML = `<div style="color:#ef4444;padding:1rem">Error loading students: ${err.message}</div>`;
  }
}

function closeEnrolledModal() {
  const modal = document.getElementById('enrolledModal');
  if (modal) modal.classList.remove('show');
}

function goToEnrollment() {
  window.location.href = 'enrollment.html';
}

// ====================================================================
// -------- RESULTS PAGE --------
// Course-based: selecting course filters students to enrolled-only
// ====================================================================

let _allResultCourses = [];

async function initResults() {
  const user = requireAuth(['admin', 'teacher']);
  if (!user) return;
  initNav();
  initSearch();

  // Load courses for filter + modal
  try {
    _allResultCourses = await apiFetch('/courses');
    const filterSel = document.getElementById('resCourseFilter');
    const modalCoursesSel = document.getElementById('rCourse');
    _allResultCourses.forEach(c => {
      if (filterSel) filterSel.appendChild(new Option(`${c.Course_ID} – ${c.Course_Name}`, c.Course_ID));
      if (modalCoursesSel) modalCoursesSel.appendChild(new Option(`${c.Course_ID} – ${c.Course_Name}`, c.Course_ID));
    });
  } catch (e) {}

  await loadResults();

  const form = document.getElementById('modalForm');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form));
      try {
        if (currentEditId) {
          await apiFetch(`/results/${currentEditId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Result updated!');
        } else {
          await apiFetch('/results', { method: 'POST', body: JSON.stringify(body) });
          toast('Result added!');
        }
        closeModal();
        await loadResults();
      } catch (err) { toast(err.message, 'error'); }
    });
  }
}

// When course is selected in modal, load only enrolled students
async function loadEnrolledStudentsForRes() {
  const courseId = document.getElementById('rCourse').value;
  const sSel = document.getElementById('rStudent');
  const hint = document.getElementById('resStudentHint');
  sSel.innerHTML = '<option value="">Loading...</option>';
  if (!courseId) {
    sSel.innerHTML = '<option value="">Select Course First</option>';
    if (hint) hint.textContent = '(select course first)';
    return;
  }
  try {
    const enrolled = await apiFetch(`/enrollment/by-course/${courseId}`);
    sSel.innerHTML = '<option value="">Select Student</option>';
    if (enrolled.length === 0) {
      sSel.innerHTML = '<option value="">No enrolled students</option>';
      if (hint) hint.textContent = '(no students enrolled in this course)';
      return;
    }
    enrolled.forEach(s => sSel.appendChild(new Option(s.Student_Name, s.Student_ID)));
    if (hint) hint.textContent = `(${enrolled.length} enrolled students)`;
  } catch (err) {
    sSel.innerHTML = '<option value="">Error loading students</option>';
  }
}

function openResModal() {
  // Reset student dropdown
  const sSel = document.getElementById('rStudent');
  if (sSel) sSel.innerHTML = '<option value="">Select Course First</option>';
  const hint = document.getElementById('resStudentHint');
  if (hint) hint.textContent = '(select course first)';
  openModal('Add Result');
}

async function filterResultsByCourse() {
  const courseId = document.getElementById('resCourseFilter').value;
  await loadResults(courseId);
}

async function loadResults(courseId = '') {
  const tbody = document.getElementById('resultsBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="7" class="skeleton" style="height:40px"></td></tr>';
  const user = getUser();
  try {
    const endpoint = courseId ? `/results?course_id=${courseId}` : '/results';
    const results = await apiFetch(endpoint);
    if (results.length === 0) {
      tbody.innerHTML = '<tr class="no-data-row"><td colspan="7"><i class="fa-solid fa-inbox"></i> No results found.</td></tr>';
      return;
    }
    tbody.innerHTML = results.map(r => {
      const gc = r.Grade?.startsWith('A') ? '#059669' : r.Grade?.startsWith('B') ? '#0284c7' : r.Grade?.startsWith('C') ? '#f59e0b' : '#ef4444';
      return `<tr>
        <td>${r.Result_ID}</td>
        <td>${r.Student_Name || r.Student_ID}</td>
        <td><span style="font-size:.85rem;background:var(--light-blue);color:var(--primary-blue);padding:2px 7px;border-radius:10px">${r.Course_ID}</span> ${r.Course_Name || ''}</td>
        <td><strong style="color:${gc}">${r.Grade}</strong></td>
        <td>${r.GPA || '—'}</td>
        <td>${r.Semester || '—'} ${r.Year || ''}</td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="editResult(${r.Result_ID})"><i class="fa-solid fa-pen"></i></button>
          ${user.role === 'admin' ? `<button class="btn-danger" onclick="deleteResult(${r.Result_ID})"><i class="fa-solid fa-trash"></i></button>` : ''}
        </div></td>
      </tr>`;
    }).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function editResult(id) {
  try {
    const r = await apiFetch(`/results/${id}`);
    // First set course, then load students for that course
    document.getElementById('rCourse').value = r.Course_ID;
    await loadEnrolledStudentsForRes();
    document.getElementById('rStudent').value = r.Student_ID;
    document.getElementById('rGrade').value = r.Grade;
    document.getElementById('rGPA').value = r.GPA || '';
    document.getElementById('rSemester').value = r.Semester || '';
    document.getElementById('rYear').value = r.Year || '';
    openModal('Edit Result', id);
  } catch (err) { toast(err.message, 'error'); }
}

async function deleteResult(id) {
  if (!confirm('Delete this result?')) return;
  try {
    await apiFetch(`/results/${id}`, { method: 'DELETE' });
    toast('Result deleted.');
    const cf = document.getElementById('resCourseFilter');
    await loadResults(cf ? cf.value : '');
  } catch (err) { toast(err.message, 'error'); }
}

// ====================================================================
// -------- ATTENDANCE PAGE --------
// Per-course stats + course filter + enrolled-students-only in form
// ====================================================================

let _allAttCourses = [];

async function initAttendance() {
  const user = requireAuth(['admin', 'teacher']);
  if (!user) return;
  initNav();
  initSearch();

  try {
    _allAttCourses = await apiFetch('/courses');
    const filterSel = document.getElementById('attCourseFilter');
    const modalCoursesSel = document.getElementById('aCourse');
    _allAttCourses.forEach(c => {
      if (filterSel) filterSel.appendChild(new Option(`${c.Course_ID} – ${c.Course_Name}`, c.Course_ID));
      if (modalCoursesSel) modalCoursesSel.appendChild(new Option(`${c.Course_ID} – ${c.Course_Name}`, c.Course_ID));
    });
  } catch (e) {}

  // Load stats + records in parallel
  await Promise.all([loadAttendanceStats(), loadAttendance()]);

  const form = document.getElementById('modalForm');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form));
      try {
        if (currentEditId) {
          await apiFetch(`/attendance/${currentEditId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Attendance updated!');
        } else {
          await apiFetch('/attendance', { method: 'POST', body: JSON.stringify(body) });
          toast('Attendance recorded!');
        }
        closeModal();
        const cf = document.getElementById('attCourseFilter');
        await Promise.all([loadAttendanceStats(), loadAttendance(cf ? cf.value : '')]);
      } catch (err) { toast(err.message, 'error'); }
    });
  }
}

// Per-course attendance stat cards
async function loadAttendanceStats() {
  const grid = document.getElementById('attStatsGrid');
  if (!grid) return;
  try {
    const stats = await apiFetch('/attendance/stats');
    if (stats.length === 0) { grid.innerHTML = '<p style="color:var(--text-light)">No attendance data yet.</p>'; return; }
    grid.innerHTML = stats.map(s => {
      const total = (s.present_count || 0) + (s.absent_count || 0) + (s.late_count || 0);
      const pct = total > 0 ? Math.round((s.present_count / total) * 100) : 0;
      const barColor = pct >= 75 ? 'var(--primary-green)' : pct >= 50 ? '#f59e0b' : '#ef4444';
      return `
        <div style="background:var(--card-bg);border:1px solid var(--border-color);border-radius:10px;padding:1rem;box-shadow:var(--shadow-sm)">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.5rem">
            <div>
              <div style="font-weight:600;color:var(--text-dark);font-size:.92rem">${s.Course_Name}</div>
              <div style="font-size:.78rem;color:var(--text-light)">${s.Course_ID} · ${s.total_classes || 0} classes held</div>
            </div>
            <span style="font-size:1.1rem;font-weight:700;color:${barColor}">${pct}%</span>
          </div>
          <div style="height:6px;background:var(--border-color);border-radius:3px;overflow:hidden">
            <div style="height:100%;width:${pct}%;background:${barColor};border-radius:3px;transition:.4s"></div>
          </div>
          <div style="display:flex;gap:.75rem;margin-top:.5rem;font-size:.78rem;color:var(--text-light)">
            <span style="color:var(--primary-green)">✓ ${s.present_count || 0} Present</span>
            <span style="color:#ef4444">✗ ${s.absent_count || 0} Absent</span>
            ${s.late_count > 0 ? `<span style="color:#f59e0b">⏱ ${s.late_count} Late</span>` : ''}
          </div>
        </div>`;
    }).join('');
  } catch (err) { if (grid) grid.innerHTML = ''; }
}

// When course is selected in form, load enrolled students only
async function loadEnrolledStudentsForAtt() {
  const courseId = document.getElementById('aCourse').value;
  const sSel = document.getElementById('aStudent');
  const hint = document.getElementById('attStudentHint');
  sSel.innerHTML = '<option value="">Loading...</option>';
  if (!courseId) {
    sSel.innerHTML = '<option value="">Select Course First</option>';
    if (hint) hint.textContent = '(select course first)';
    return;
  }
  try {
    const enrolled = await apiFetch(`/enrollment/by-course/${courseId}`);
    sSel.innerHTML = '<option value="">Select Student</option>';
    if (enrolled.length === 0) {
      sSel.innerHTML = '<option value="">No enrolled students</option>';
      if (hint) hint.textContent = '(no students enrolled in this course)';
      return;
    }
    enrolled.forEach(s => sSel.appendChild(new Option(s.Student_Name, s.Student_ID)));
    if (hint) hint.textContent = `(${enrolled.length} enrolled)`;
  } catch (err) {
    sSel.innerHTML = '<option value="">Error</option>';
  }
}

function openAttModal() {
  const sSel = document.getElementById('aStudent');
  if (sSel) sSel.innerHTML = '<option value="">Select Course First</option>';
  const hint = document.getElementById('attStudentHint');
  if (hint) hint.textContent = '(select course first)';
  openModal('Record Attendance');
}

async function filterAttendanceByCourse() {
  const courseId = document.getElementById('attCourseFilter').value;
  await loadAttendance(courseId);
}

async function loadAttendance(courseId = '') {
  const tbody = document.getElementById('attendanceBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="6" class="skeleton" style="height:40px"></td></tr>';
  const user = getUser();
  try {
    const endpoint = courseId ? `/attendance?course_id=${courseId}` : '/attendance';
    const records = await apiFetch(endpoint);
    if (records.length === 0) {
      tbody.innerHTML = '<tr class="no-data-row"><td colspan="6"><i class="fa-solid fa-inbox"></i> No records found.</td></tr>';
      return;
    }
    tbody.innerHTML = records.map(a => `
      <tr>
        <td>${a.Attendance_ID}</td>
        <td>${a.Student_Name || a.Student_ID}</td>
        <td><span style="font-size:.85rem;background:var(--light-blue);color:var(--primary-blue);padding:2px 7px;border-radius:10px">${a.Course_ID}</span></td>
        <td>${a.Date ? new Date(a.Date).toLocaleDateString() : '—'}</td>
        <td><span class="att-${a.Status?.toLowerCase()}">${a.Status}</span></td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="editAttendance(${a.Attendance_ID})"><i class="fa-solid fa-pen"></i></button>
          ${user.role === 'admin' ? `<button class="btn-danger" onclick="deleteAttendance(${a.Attendance_ID})"><i class="fa-solid fa-trash"></i></button>` : ''}
        </div></td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function editAttendance(id) {
  try {
    const a = await apiFetch(`/attendance/${id}`);
    // Set course first, then load enrolled students
    document.getElementById('aCourse').value = a.Course_ID;
    await loadEnrolledStudentsForAtt();
    document.getElementById('aStudent').value = a.Student_ID;
    document.getElementById('aDate').value = a.Date ? a.Date.split('T')[0] : '';
    document.getElementById('aStatus').value = a.Status;
    openModal('Edit Attendance', id);
  } catch (err) { toast(err.message, 'error'); }
}

async function deleteAttendance(id) {
  if (!confirm('Delete this attendance record?')) return;
  try {
    await apiFetch(`/attendance/${id}`, { method: 'DELETE' });
    toast('Record deleted.');
    const cf = document.getElementById('attCourseFilter');
    await Promise.all([loadAttendanceStats(), loadAttendance(cf ? cf.value : '')]);
  } catch (err) { toast(err.message, 'error'); }
}

// ====================================================================
// -------- ENROLLMENT PAGE --------
// ====================================================================

async function initEnrollment() {
  const user = requireAuth(['admin']);
  if (!user) return;
  initNav();
  initSearch();
  try {
    const [students, courses] = await Promise.all([apiFetch('/students'), apiFetch('/courses')]);
    const sSel = document.getElementById('eStudent');
    const cSel = document.getElementById('eCourse');
    if (sSel) students.forEach(s => sSel.appendChild(new Option(s.Name, s.Student_ID)));
    if (cSel) courses.forEach(c => cSel.appendChild(new Option(`${c.Course_ID} – ${c.Course_Name}`, c.Course_ID)));
  } catch (e) {}
  await loadEnrollment();
  const form = document.getElementById('modalForm');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form));
      try {
        if (currentEditId) {
          await apiFetch(`/enrollment/${currentEditId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Enrollment updated!');
        } else {
          await apiFetch('/enrollment', { method: 'POST', body: JSON.stringify(body) });
          toast('Student enrolled in course!');
        }
        closeModal();
        await loadEnrollment();
      } catch (err) { toast(err.message, 'error'); }
    });
  }
}

async function loadEnrollment() {
  const tbody = document.getElementById('enrollmentBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="6" class="skeleton" style="height:40px"></td></tr>';
  try {
    const records = await apiFetch('/enrollment');
    if (records.length === 0) {
      tbody.innerHTML = '<tr class="no-data-row"><td colspan="6"><i class="fa-solid fa-inbox"></i> No enrollments found.</td></tr>';
      return;
    }
    tbody.innerHTML = records.map(e => `
      <tr>
        <td>${e.Enroll_ID}</td>
        <td>${e.Student_Name || e.Student_ID}</td>
        <td><span style="font-size:.85rem;background:var(--light-blue);color:var(--primary-blue);padding:2px 7px;border-radius:10px">${e.Course_ID}</span> ${e.Course_Name || ''}</td>
        <td>${e.Semester || '—'}</td>
        <td>${e.Year || '—'}</td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="editEnrollment(${e.Enroll_ID})"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-danger" onclick="deleteEnrollment(${e.Enroll_ID})"><i class="fa-solid fa-trash"></i></button>
        </div></td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function editEnrollment(id) {
  try {
    const e = await apiFetch(`/enrollment/${id}`);
    document.getElementById('eStudent').value = e.Student_ID;
    document.getElementById('eCourse').value = e.Course_ID;
    document.getElementById('eSemester').value = e.Semester || '';
    document.getElementById('eYear').value = e.Year || '';
    openModal('Edit Enrollment', id);
  } catch (err) { toast(err.message, 'error'); }
}

async function deleteEnrollment(id) {
  if (!confirm('Remove this enrollment? Attendance and results for this student/course will remain.')) return;
  try {
    await apiFetch(`/enrollment/${id}`, { method: 'DELETE' });
    toast('Enrollment removed.');
    await loadEnrollment();
  } catch (err) { toast(err.message, 'error'); }
}

// -------- PAYMENTS PAGE --------

async function initPayments() {
  const user = requireAuth(['admin']);
  if (!user) return;
  initNav();
  initSearch();
  try {
    const students = await apiFetch('/students');
    const sSel = document.getElementById('pStudent');
    if (sSel) students.forEach(s => sSel.appendChild(new Option(s.Name, s.Student_ID)));
  } catch (e) {}
  await loadPayments();
  const form = document.getElementById('modalForm');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form));
      try {
        if (currentEditId) {
          await apiFetch(`/payments/${currentEditId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Payment updated!');
        } else {
          await apiFetch('/payments', { method: 'POST', body: JSON.stringify(body) });
          toast('Payment recorded!');
        }
        closeModal();
        await loadPayments();
      } catch (err) { toast(err.message, 'error'); }
    });
  }
}

async function loadPayments() {
  const tbody = document.getElementById('paymentsBody');
  if (!tbody) return;
  try {
    const payments = await apiFetch('/payments');
    if (payments.length === 0) {
      tbody.innerHTML = '<tr class="no-data-row"><td colspan="6">No payments found.</td></tr>';
      return;
    }
    tbody.innerHTML = payments.map(p => `
      <tr>
        <td>${p.Payment_ID}</td>
        <td>${p.Student_Name || p.Student_ID}</td>
        <td>৳${Number(p.Amount).toLocaleString()}</td>
        <td>${p.Payment_Date ? new Date(p.Payment_Date).toLocaleDateString() : '—'}</td>
        <td><span class="status ${p.Status?.toLowerCase() === 'paid' ? 'active' : 'inactive'}">${p.Status}</span></td>
        <td>${p.Method || '—'}</td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="editPayment(${p.Payment_ID})"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-danger" onclick="deletePayment(${p.Payment_ID})"><i class="fa-solid fa-trash"></i></button>
        </div></td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function editPayment(id) {
  try {
    const p = await apiFetch(`/payments/${id}`);
    document.getElementById('pStudent').value = p.Student_ID;
    document.getElementById('pAmount').value = p.Amount;
    document.getElementById('pDate').value = p.Payment_Date ? p.Payment_Date.split('T')[0] : '';
    document.getElementById('pStatus').value = p.Status || 'Pending';
    document.getElementById('pMethod').value = p.Method || '';
    openModal('Edit Payment', id);
  } catch (err) { toast(err.message, 'error'); }
}

async function deletePayment(id) {
  if (!confirm('Delete this payment record?')) return;
  try {
    await apiFetch(`/payments/${id}`, { method: 'DELETE' });
    toast('Payment deleted.');
    await loadPayments();
  } catch (err) { toast(err.message, 'error'); }
}

// -------- STUDENT PORTAL --------

async function initStudentPortal() {
  const user = requireAuth(['student']);
  if (!user) return;
  initNav();
  try {
    const [profile, results, attendance] = await Promise.all([
      apiFetch('/students/my'),
      apiFetch('/results/my'),
      apiFetch('/attendance/my')
    ]);

    document.getElementById('portalName').textContent = profile.Name;
    document.getElementById('portalDept').textContent = `${profile.Dept_Name || 'N/A'} | Student ID: ${profile.Student_ID}`;
    document.getElementById('pName').textContent = profile.Name;
    document.getElementById('pEmail').textContent = profile.Email;
    document.getElementById('pPhone').textContent = profile.Phone || '—';
    document.getElementById('pAddress').textContent = profile.Address || '—';
    document.getElementById('pGender').textContent = profile.Gender || '—';
    document.getElementById('pDob').textContent = profile.Date_of_Birth ? new Date(profile.Date_of_Birth).toLocaleDateString() : '—';
    document.getElementById('pDept').textContent = profile.Dept_Name || '—';
    document.getElementById('pYear').textContent = profile.Admission_Year || '—';

    // Results grouped by course
    const rBody = document.getElementById('myResultsBody');
    if (rBody) {
      if (results.length === 0) {
        rBody.innerHTML = '<tr class="no-data-row"><td colspan="5">No results yet.</td></tr>';
      } else {
        rBody.innerHTML = results.map(r => {
          const gc = r.Grade?.startsWith('A') ? 'grade-A' : r.Grade?.startsWith('B') ? 'grade-B' : r.Grade?.startsWith('C') ? 'grade-C' : 'grade-D';
          return `<tr>
            <td>${r.Course_Name || r.Course_ID}</td>
            <td><span class="grade-badge ${gc}">${r.Grade}</span></td>
            <td>${r.GPA || '—'}</td>
            <td>${r.Semester || '—'}</td>
            <td>${r.Year || '—'}</td>
          </tr>`;
        }).join('');
      }
    }

    // Attendance per course
    const aBody = document.getElementById('myAttendanceBody');
    if (aBody) {
      if (attendance.length === 0) {
        aBody.innerHTML = '<tr class="no-data-row"><td colspan="4">No attendance records yet.</td></tr>';
      } else {
        // Group by course for summary
        const byCourse = {};
        attendance.forEach(a => {
          if (!byCourse[a.Course_ID]) byCourse[a.Course_ID] = { name: a.Course_Name || a.Course_ID, present: 0, total: 0 };
          byCourse[a.Course_ID].total++;
          if (a.Status === 'Present') byCourse[a.Course_ID].present++;
        });
        const summaryEl = document.getElementById('attSummary');
        if (summaryEl) {
          summaryEl.innerHTML = Object.entries(byCourse).map(([cid, s]) => {
            const pct = Math.round((s.present / s.total) * 100);
            const col = pct >= 75 ? '#059669' : pct >= 50 ? '#f59e0b' : '#ef4444';
            return `<span style="margin-right:1rem"><strong>${s.name}:</strong> <span style="color:${col}">${pct}%</span> (${s.present}/${s.total})</span>`;
          }).join('');
        }
        aBody.innerHTML = attendance.map(a => `
          <tr>
            <td>${a.Course_Name || a.Course_ID}</td>
            <td>${a.Date ? new Date(a.Date).toLocaleDateString() : '—'}</td>
            <td><span class="att-${a.Status?.toLowerCase()}">${a.Status}</span></td>
          </tr>`).join('');
      }
    }
  } catch (err) { toast('Error loading your data: ' + err.message, 'error'); }
}

// -------- TEACHER PORTAL --------

async function initTeacherPortal() {
  const user = requireAuth(['teacher']);
  if (!user) return;
  initNav();
  try {
    const profile = await apiFetch('/teachers/my');
    document.getElementById('portalName').textContent = profile.Name;
    document.getElementById('portalDept').textContent = `${profile.Dept_Name || 'N/A'} | ${profile.Designation || ''}`;
    document.getElementById('tpName').textContent = profile.Name;
    document.getElementById('tpEmail').textContent = profile.Email;
    document.getElementById('tpPhone').textContent = profile.Phone || '—';
    document.getElementById('tpDesignation').textContent = profile.Designation || '—';
    document.getElementById('tpDept').textContent = profile.Dept_Name || '—';
  } catch (err) { toast('Error loading profile.', 'error'); }

  await loadStudentsForTeacher();
  await loadResultsForTeacher();
  await loadAttendanceForTeacher();
}

async function loadStudentsForTeacher() {
  const tbody = document.getElementById('tpStudentsBody');
  if (!tbody) return;
  try {
    const students = await apiFetch('/students');
    tbody.innerHTML = students.map(s => `
      <tr>
        <td>${s.Student_ID}</td>
        <td>${s.Name}</td>
        <td>${s.Dept_Name || '—'}</td>
        <td>${s.Email}</td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function loadResultsForTeacher() {
  const tbody = document.getElementById('tpResultsBody');
  if (!tbody) return;
  try {
    const results = await apiFetch('/results');
    if (results.length === 0) { tbody.innerHTML = '<tr class="no-data-row"><td colspan="5">No results.</td></tr>'; return; }
    tbody.innerHTML = results.map(r => `
      <tr>
        <td>${r.Student_Name || r.Student_ID}</td>
        <td>${r.Course_Name || r.Course_ID}</td>
        <td><strong>${r.Grade}</strong></td>
        <td>${r.GPA || '—'}</td>
        <td>${r.Semester || ''} ${r.Year || ''}</td>
        <td><button class="btn-edit" onclick="editResult(${r.Result_ID})"><i class="fa-solid fa-pen"></i></button></td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function loadAttendanceForTeacher() {
  const tbody = document.getElementById('tpAttendanceBody');
  if (!tbody) return;
  try {
    const att = await apiFetch('/attendance');
    if (att.length === 0) { tbody.innerHTML = '<tr class="no-data-row"><td colspan="4">No records.</td></tr>'; return; }
    tbody.innerHTML = att.map(a => `
      <tr>
        <td>${a.Student_Name || a.Student_ID}</td>
        <td>${a.Course_Name || a.Course_ID}</td>
        <td>${a.Date ? new Date(a.Date).toLocaleDateString() : '—'}</td>
        <td><span class="att-${a.Status?.toLowerCase()}">${a.Status}</span></td>
        <td><button class="btn-edit" onclick="editAttendance(${a.Attendance_ID})"><i class="fa-solid fa-pen"></i></button></td>
      </tr>`).join('');
  } catch (err) { toast(err.message, 'error'); }
}
