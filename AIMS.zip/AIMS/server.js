require('dotenv').config();
const express = require('express');
const session = require('express-session');
const cors = require('cors');
const path = require('path');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: true, credentials: true }));

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'aims_secret_key_2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/students', require('./routes/students'));
app.use('/api/teachers', require('./routes/teachers'));
app.use('/api/courses', require('./routes/courses'));
app.use('/api/departments', require('./routes/departments'));
app.use('/api/results', require('./routes/results'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/enrollment', require('./routes/enrollment'));
app.use('/api/payments', require('./routes/payments'));

// Dashboard stats endpoint
app.get('/api/stats', async (req, res) => {
  if (!req.session || !req.session.user)
    return res.status(401).json({ error: 'Not authenticated.' });
  const pool = require('./config/db');
  try {
    const [[{ students }]] = await pool.execute('SELECT COUNT(*) AS students FROM student');
    const [[{ teachers }]] = await pool.execute('SELECT COUNT(*) AS teachers FROM teacher');
    const [[{ courses }]] = await pool.execute('SELECT COUNT(*) AS courses FROM course');
    const [[{ revenue }]] = await pool.execute("SELECT COALESCE(SUM(Amount), 0) AS revenue FROM payment WHERE Status = 'Paid'");
    res.json({ students, teachers, courses, revenue });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// Catch-all: serve index.html for SPA navigation
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🎓 AIMS Server running at http://localhost:${PORT}`);
  console.log(`   Login at: http://localhost:${PORT}/index.html\n`);
});
