// Run this script ONCE to update the database with correct bcrypt password hashes.
// Usage: node generate-passwords.js
// Requires: npm install bcryptjs mysql2 dotenv

require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

const users = [
  { username: 'NSU',    password: 'NSU123',   role: 'admin',   reference_id: null, full_name: 'System Administrator' },
  { username: 'teacher1', password: 'teacher123', role: 'teacher', reference_id: 1,    full_name: 'Ms. Tanzilah Noor Shabnam' },
  { username: 'teacher2', password: 'teacher123', role: 'teacher', reference_id: 2,    full_name: 'Md. Amanullah Shah' },
  { username: 'student1', password: 'student123', role: 'student', reference_id: 1,    full_name: 'Nabila Nusrat' },
  { username: 'student2', password: 'student123', role: 'student', reference_id: 2,    full_name: 'Redoan Bin Anwar Rafi' },
  { username: 'student3', password: 'student123', role: 'student', reference_id: 3,    full_name: 'Md Shakil Ahmed Shihab' },
];

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'aims_db'
  });

  await conn.execute('DELETE FROM users');

  for (const u of users) {
    const hash = await bcrypt.hash(u.password, 10);
    await conn.execute(
      'INSERT INTO users (username, password_hash, role, reference_id, full_name) VALUES (?, ?, ?, ?, ?)',
      [u.username, hash, u.role, u.reference_id, u.full_name]
    );
    console.log(`✓ Created user: ${u.username} (password: ${u.password})`);
  }

  console.log('\n✅ All passwords set successfully!');
  console.log('\n📋 Login Credentials:');
  users.forEach(u => console.log(`   ${u.role.padEnd(8)} | ${u.username.padEnd(10)} | ${u.password}`));
  await conn.end();
}

main().catch(console.error);
