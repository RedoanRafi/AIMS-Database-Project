// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) {
    return next();
  }
  return res.status(401).json({ error: 'Not authenticated. Please log in.' });
};

// Middleware to allow only Admin
const isAdmin = (req, res, next) => {
  if (req.session && req.session.user && req.session.user.role === 'admin') {
    return next();
  }
  return res.status(403).json({ error: 'Access denied. Admins only.' });
};

// Middleware to allow Admin or Teacher
const isAdminOrTeacher = (req, res, next) => {
  if (req.session && req.session.user &&
      (req.session.user.role === 'admin' || req.session.user.role === 'teacher')) {
    return next();
  }
  return res.status(403).json({ error: 'Access denied. Admins and Teachers only.' });
};

module.exports = { isAuthenticated, isAdmin, isAdminOrTeacher };
