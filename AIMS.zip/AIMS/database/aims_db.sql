-- ============================================================
-- AIMS Database - Academic Information Management System
-- CSE311L Project
-- ============================================================
-- ACADEMIC FLOW:
--   Admin creates Courses → assigns a Teacher to each Course
--   Admin enrolls Students into Courses (enrollment table)
--   Attendance is recorded per Student per Course (only enrolled students)
--   Results (grades) are given per Student per Course (only enrolled students)
-- ============================================================

CREATE DATABASE IF NOT EXISTS aims_db;
USE aims_db;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS payment;
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS result;
DROP TABLE IF EXISTS enrollment;
DROP TABLE IF EXISTS course;
DROP TABLE IF EXISTS teacher;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS department;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Table: department
-- ============================================================
CREATE TABLE department (
  Dept_ID int(11) NOT NULL AUTO_INCREMENT,
  Dept_Name varchar(100) NOT NULL,
  Office_Location varchar(100) DEFAULT NULL,
  Budget decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (Dept_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO department VALUES
(1, 'Electrical & Computer Engineering', 'SAC 9th Floor', 5000000.00),
(2, 'Business Administration', 'NAC 6th Floor', 4500000.00),
(3, 'English & Humanities', 'NAC 4th Floor', 2000000.00);

-- ============================================================
-- Table: student
-- ============================================================
CREATE TABLE student (
  Student_ID int(11) NOT NULL AUTO_INCREMENT,
  Name varchar(100) NOT NULL,
  Email varchar(100) NOT NULL,
  Phone varchar(15) DEFAULT NULL,
  Address varchar(255) DEFAULT NULL,
  Gender varchar(10) DEFAULT NULL,
  Date_of_Birth date DEFAULT NULL,
  Admission_Year year(4) DEFAULT NULL,
  Dept_ID int(11) DEFAULT NULL,
  PRIMARY KEY (Student_ID),
  UNIQUE KEY Email (Email),
  FOREIGN KEY (Dept_ID) REFERENCES department(Dept_ID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO student VALUES
(1, 'Nabila Nusrat',          'nabila.nusrat@northsouth.edu',  '01800000001', 'Bashundhara, Dhaka', 'Female', '2001-05-14', '2020', 1),
(2, 'Redoan Bin Anwar Rafi',  'redoan.rafi@northsouth.edu',    '01800000002', 'Mirpur, Dhaka',      'Male',   '2002-08-21', '2022', 1),
(3, 'Md Shakil Ahmed Shihab', 'shakil.shihab@northsouth.edu',  '01800000003', 'Uttara, Dhaka',      'Male',   '2001-11-03', '2021', 1);

-- ============================================================
-- Table: teacher
-- ============================================================
CREATE TABLE teacher (
  Teacher_ID int(11) NOT NULL AUTO_INCREMENT,
  Name varchar(100) NOT NULL,
  Email varchar(100) NOT NULL,
  Phone varchar(15) DEFAULT NULL,
  Designation varchar(50) DEFAULT NULL,
  Salary decimal(10,2) DEFAULT NULL,
  Dept_ID int(11) DEFAULT NULL,
  PRIMARY KEY (Teacher_ID),
  UNIQUE KEY Email (Email),
  FOREIGN KEY (Dept_ID) REFERENCES department(Dept_ID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO teacher VALUES
(1, 'Ms. Tanzilah Noor Shabnam', 'tanzilah.shabnam@northsouth.edu', '01700000001', 'Lecturer',        60000.00, 1),
(2, 'Md. Amanullah Shah',        'amanullah.shah@northsouth.edu',   '01700000002', 'Lab Instructor',  40000.00, 1);

-- ============================================================
-- Table: users (Authentication)
-- ============================================================
CREATE TABLE users (
  user_id int(11) NOT NULL AUTO_INCREMENT,
  username varchar(50) NOT NULL,
  password_hash varchar(255) NOT NULL,
  role enum('admin','teacher','student') NOT NULL,
  reference_id int(11) DEFAULT NULL COMMENT 'Links to student/teacher ID',
  full_name varchar(100) NOT NULL,
  created_at timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Default credentials: admin/admin123, teacher1/teacher123, student1/student123
INSERT INTO users (username, password_hash, role, reference_id, full_name) VALUES
('admin',    '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin',   NULL, 'System Administrator'),
('teacher1', '$2a$10$8K1p/a0dR1oxieB1q2bAqOB4qQBbXbBQlLFGlLJaMLYq.A0s0IeDS', 'teacher', 1,    'Ms. Tanzilah Noor Shabnam'),
('teacher2', '$2a$10$8K1p/a0dR1oxieB1q2bAqOB4qQBbXbBQlLFGlLJaMLYq.A0s0IeDS', 'teacher', 2,    'Md. Amanullah Shah'),
('student1', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 1,    'Nabila Nusrat'),
('student2', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 2,    'Redoan Bin Anwar Rafi'),
('student3', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 3,    'Md Shakil Ahmed Shihab');

-- Run `node generate-passwords.js` after setup to regenerate proper bcrypt hashes.

-- ============================================================
-- Table: course
-- Admin assigns ONE teacher per course via Teacher_ID
-- ============================================================
CREATE TABLE course (
  Course_ID varchar(10) NOT NULL,
  Course_Name varchar(100) NOT NULL,
  Credits int(11) NOT NULL,
  Dept_ID int(11) DEFAULT NULL,
  Teacher_ID int(11) DEFAULT NULL COMMENT 'Admin assigns teacher to course',
  PRIMARY KEY (Course_ID),
  FOREIGN KEY (Dept_ID) REFERENCES department(Dept_ID) ON DELETE CASCADE,
  FOREIGN KEY (Teacher_ID) REFERENCES teacher(Teacher_ID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO course VALUES
('CSE311',  'Database Systems',      3, 1, 1),
('CSE311L', 'Database Systems Lab',  1, 1, 2),
('CSE221',  'Computer Architecture', 3, 1, 1);

-- ============================================================
-- Table: enrollment
-- Admin enrolls students into specific courses.
-- Attendance and Results are ONLY allowed for enrolled students.
-- ============================================================
CREATE TABLE enrollment (
  Enroll_ID int(11) NOT NULL AUTO_INCREMENT,
  Student_ID int(11) DEFAULT NULL,
  Course_ID varchar(10) DEFAULT NULL,
  Semester varchar(15) DEFAULT NULL,
  Year year(4) DEFAULT NULL,
  PRIMARY KEY (Enroll_ID),
  UNIQUE KEY unique_enrollment (Student_ID, Course_ID),
  FOREIGN KEY (Student_ID) REFERENCES student(Student_ID) ON DELETE CASCADE,
  FOREIGN KEY (Course_ID) REFERENCES course(Course_ID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO enrollment VALUES
(1, 1, 'CSE311L', 'Spring', '2026'),
(2, 2, 'CSE311L', 'Spring', '2026'),
(3, 3, 'CSE311L', 'Spring', '2026'),
(4, 1, 'CSE311',  'Spring', '2026'),
(5, 2, 'CSE311',  'Spring', '2026'),
(6, 3, 'CSE221',  'Spring', '2026');

-- ============================================================
-- Table: result
-- Grade per student per course. Student must be enrolled first.
-- ============================================================
CREATE TABLE result (
  Result_ID int(11) NOT NULL AUTO_INCREMENT,
  Student_ID int(11) DEFAULT NULL,
  Course_ID varchar(10) DEFAULT NULL,
  Grade varchar(5) DEFAULT NULL,
  GPA decimal(3,2) DEFAULT NULL,
  Semester varchar(15) DEFAULT NULL,
  Year year(4) DEFAULT NULL,
  PRIMARY KEY (Result_ID),
  FOREIGN KEY (Student_ID) REFERENCES student(Student_ID) ON DELETE CASCADE,
  FOREIGN KEY (Course_ID) REFERENCES course(Course_ID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO result VALUES
(1, 1, 'CSE311L', 'A',  4.00, 'Spring', '2026'),
(2, 2, 'CSE311L', 'A-', 3.70, 'Spring', '2026'),
(3, 3, 'CSE311L', 'B+', 3.30, 'Spring', '2026'),
(4, 1, 'CSE311',  'A',  4.00, 'Spring', '2026'),
(5, 2, 'CSE311',  'B+', 3.30, 'Spring', '2026');

-- ============================================================
-- Table: attendance
-- Recorded per student per course per date. Student must be enrolled.
-- ============================================================
CREATE TABLE attendance (
  Attendance_ID int(11) NOT NULL AUTO_INCREMENT,
  Student_ID int(11) DEFAULT NULL,
  Course_ID varchar(10) DEFAULT NULL,
  Date date DEFAULT NULL,
  Status varchar(20) DEFAULT NULL,
  PRIMARY KEY (Attendance_ID),
  FOREIGN KEY (Student_ID) REFERENCES student(Student_ID) ON DELETE CASCADE,
  FOREIGN KEY (Course_ID) REFERENCES course(Course_ID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO attendance VALUES
(1, 1, 'CSE311L', '2026-03-10', 'Present'),
(2, 2, 'CSE311L', '2026-03-10', 'Present'),
(3, 3, 'CSE311L', '2026-03-10', 'Absent'),
(4, 1, 'CSE311L', '2026-03-17', 'Present'),
(5, 2, 'CSE311L', '2026-03-17', 'Absent'),
(6, 3, 'CSE311L', '2026-03-17', 'Present'),
(7, 1, 'CSE311',  '2026-03-10', 'Present'),
(8, 2, 'CSE311',  '2026-03-10', 'Present'),
(9, 1, 'CSE311',  '2026-03-17', 'Present'),
(10,2, 'CSE311',  '2026-03-17', 'Late');

-- ============================================================
-- Table: payment
-- ============================================================
CREATE TABLE payment (
  Payment_ID int(11) NOT NULL AUTO_INCREMENT,
  Student_ID int(11) DEFAULT NULL,
  Amount decimal(10,2) NOT NULL,
  Payment_Date date DEFAULT NULL,
  Status varchar(20) DEFAULT NULL,
  Method varchar(50) DEFAULT NULL,
  PRIMARY KEY (Payment_ID),
  FOREIGN KEY (Student_ID) REFERENCES student(Student_ID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO payment VALUES
(1, 1, 25000.00, '2026-01-15', 'Paid',    'bKash'),
(2, 2, 25000.00, '2026-01-20', 'Paid',    'Bank Transfer'),
(3, 3, 25000.00, '2026-01-18', 'Pending', 'Bank Transfer');
